// Logic in posts.js
