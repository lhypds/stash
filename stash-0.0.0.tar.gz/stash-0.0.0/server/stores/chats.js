import { UA, matchesHost, fetchHtml, metaContent, stripTags, truncate, PREVIEW_LENGTH } from "../utils/html.js";
import { readRenderedTitle, readRenderedConversation } from "../utils/screenshot.js";

const CHAT_PLATFORMS = [
  // ChatGPT's og:description is a static marketing blurb, not the shared
  // conversation — renderedPreview reads the actual Q&A turns out of the
  // client-rendered page instead (see readRenderedConversation).
  { label: "ChatGPT", hosts: ["chatgpt.com", "chat.openai.com"], titleInTag: true, renderedPreview: true },
  { label: "Gemini", hosts: ["gemini.google.com", "g.co"] },
  { label: "Grok", hosts: ["grok.com", "x.ai"] },
  { label: "Claude", hosts: ["claude.ai"] },
  {
    label: "Doubao",
    hosts: ["doubao.com"],
    renderedTitle: true,
    transientTitles: ["豆包 - 你的 AI 智能助手"],
  },
];

export const chatPlatformFor = (host) => CHAT_PLATFORMS.find((platform) => matchesHost(platform, host));

// Drop a trailing/leading brand from a shared-chat title (e.g. "… - ChatGPT").
function stripBrand(title, label) {
  if (!label) return title;
  const esc = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const sep = "\\s*[-–—|:·]\\s*";
  const stripped = title
    .replace(new RegExp(`^${esc}${sep}`, "i"), "")
    .replace(new RegExp(`${sep}${esc}$`, "i"), "")
    .trim();
  return stripped || title;
}

export async function analyzeChat(url) {
  const host = new URL(url).hostname.replace(/^www\./, "");
  const platform = chatPlatformFor(host);
  if (platform?.renderedTitle) {
    const { title, finalUrl } = await readRenderedTitle(url, platform.transientTitles);
    const loc = new URL(finalUrl);
    return {
      kind: "chat",
      name: title,
      byline: platform.label,
      icon: `${loc.origin}/favicon.ico`,
      url: finalUrl,
    };
  }
  const { html, finalUrl } = await fetchHtml(url, platform?.ua || UA, 2000000);
  const loc = new URL(finalUrl);
  const ogTitle = metaContent(html, "og:title");
  const docTitle = stripTags(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "");
  const title = (platform?.titleInTag ? docTitle || ogTitle : ogTitle || docTitle) || platform?.label || finalUrl;
  const image = metaContent(html, "og:image");
  const desc = metaContent(html, "og:description") || metaContent(html, "description");
  let preview = desc ? truncate(desc, PREVIEW_LENGTH) : null;
  if (platform?.renderedPreview) {
    try {
      const { turns } = await readRenderedConversation(finalUrl);
      if (turns.length) {
        const transcript = turns.map((turn) => `${turn.role === "user" ? "Q" : "A"}: ${turn.text}`).join("\n\n");
        preview = truncate(transcript, PREVIEW_LENGTH);
      }
    } catch (err) {
      console.error("chat conversation render failed:", err.message);
    }
  }
  return {
    kind: "chat",
    name: stripBrand(title, platform?.label),
    byline: platform?.label || metaContent(html, "og:site_name") || loc.hostname,
    icon: image ? new URL(image, finalUrl).href : `${loc.origin}/favicon.ico`,
    url: finalUrl,
    preview,
  };
}
